#pragma once
#ifdef IMPLEMENTATION_EXPORTS 
#define IMPLEMENTATION_API __declspec(dllexport)
#else
#define IMPLEMENTATION_API __declspec(dllimport)
#endif

class IMPLEMENTATION_API Factory {
public:
	void getObject(const int TYPE, void** ppv);
};