#include "pch.h"
#include "TIE_ICalculator.h"
#include <iostream>


TIE_ICalculator::TIE_ICalculator() {
	this->_pcMobile = NULL;
}

TIE_ICalculator::TIE_ICalculator(CMobile* pcMobile){
	this->_pcMobile = pcMobile;
}


TIE_ICalculator::~TIE_ICalculator() {
	this->_pcMobile->setPICalculator(NULL);
	std::cout << "TIE_ICalculator destructor" << std::endl;
}

void TIE_ICalculator::add()
{
	this->_pcMobile->add();
}

void TIE_ICalculator::subtract()
{
	this->_pcMobile->subtract();
}

void TIE_ICalculator::addRef() {
	this->_pcMobile->addRef();
}

void TIE_ICalculator::release() {
	this->_pcMobile->release();

}

void TIE_ICalculator::queryInterface(const int TYPE, void** ppv) {
	this->_pcMobile->queryInterface(TYPE, ppv);
}

IMobile* TIE_ICalculator::get_pcMobile() {
	return this->_pcMobile;
}

void TIE_ICalculator::set_pcMobile(CMobile *pcMobile) {
	this->_pcMobile = pcMobile;
}