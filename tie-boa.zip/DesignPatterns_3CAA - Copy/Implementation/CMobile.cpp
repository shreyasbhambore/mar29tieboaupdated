#include "pch.h"
#include "CMobile.h"
#include "Factory.h"
#include "TIE_ICalculator.h"
#include "TIE_IWatch.h"
#include<iostream>


CMobile::CMobile() {
	this->_piCalculator = nullptr;
	this->_piWatch = nullptr;

	this->_refCount = 0;
}

CMobile::~CMobile() {
	if (this->getPICalculator())
		delete this->_piCalculator;
	if (this->getPIWatch())
		delete this->_piWatch;
}

void CMobile::add()
{
	std::cout << "add" << std::endl;
}

void CMobile::makeCall()
{
	std::cout << "make call" << std::endl;
}

void CMobile::recieveCall()
{
	std::cout << "recieve call" << std::endl;
}

void CMobile::subtract()
{
	std::cout << "subtract" << std::endl;
}

void CMobile::time()
{
	std::cout << "time" << std::endl;
}

void CMobile::addRef() {
	this->_refCount++;
}

void CMobile::release() {
	this->_refCount--;
	if (this->_refCount == 0) delete this;
}

void CMobile::queryInterface(const int TYPE, void** ppv)
{
	switch (TYPE) {
	case 1: {
		// IMobile
		*ppv = this;
		break;
	}
	case 2: {
		// ICalculator
		if (this->_piCalculator != nullptr) *ppv = this->_piCalculator;
		else {
			TIE_ICalculator* tie_iCalculator = new TIE_ICalculator(this);
			tie_iCalculator->addRef();
			this->setPICalculator(tie_iCalculator);
			*ppv = tie_iCalculator;
		}
		break;
	}
	case 3: {
		// IWatch
		if (this->_piWatch != nullptr) *ppv = this->_piWatch;
		else {
			TIE_IWatch* tie_iWatch = new TIE_IWatch();
			tie_iWatch->set_pcMobile(this);
			tie_iWatch->addRef();
			this->setPIWatch(tie_iWatch);
			*ppv = tie_iWatch;
		}
		break;
	}
	}
}

ICalculator* CMobile::getPICalculator()
{
	return this->_piCalculator;
}

IWatch* CMobile::getPIWatch()
{
	return this->_piWatch;
}

void CMobile::setPICalculator(ICalculator* piCalculator)
{
	this->_piCalculator = piCalculator;
}

void CMobile::setPIWatch(IWatch* piWatch)
{
	this->_piWatch = piWatch;
}