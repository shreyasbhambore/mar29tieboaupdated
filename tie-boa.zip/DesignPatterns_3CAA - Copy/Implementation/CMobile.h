#pragma once
#ifdef IMPLEMENTATION_EXPORTS 
#define IMPLEMENTATION_API __declspec(dllexport)
#else
#define IMPLEMENTATION_API __declspec(dllimport)
#endif

#include "IMobile.h"
#include "ICalculator.h"
#include "IWatch.h"


class IMPLEMENTATION_API CMobile : public IMobile
{
private:
    ICalculator* _piCalculator;
    IWatch* _piWatch;

    int _refCount;
public:
    CMobile();
    ~CMobile();
    void add();
    void makeCall();
    void recieveCall();
    void subtract();
    void time();

    void addRef();
    void release();

    void queryInterface(const int TYPE, void** ppv);

    ICalculator* getPICalculator();
    IWatch* getPIWatch();

    void setPICalculator(ICalculator* piCalculator);
    void setPIWatch(IWatch* piCalculator);
};