#pragma once
#ifdef IMPLEMENTATION_EXPORTS 
#define IMPLEMENTATION_API __declspec(dllexport)
#else
#define IMPLEMENTATION_API __declspec(dllimport)
#endif

#include "CMobile.h"
#include "ICalculator.h"

class IMPLEMENTATION_API TIE_ICalculator: public ICalculator
{
private:
	CMobile* _pcMobile;
public:
	TIE_ICalculator();
	TIE_ICalculator(CMobile* pcMobile);
	~TIE_ICalculator();
	
	void add();
	void subtract();
	
	void addRef();
	void release();

	void queryInterface(const int TYPE, void** ppv);

	IMobile* get_pcMobile();
	void set_pcMobile(CMobile* pcMobile);
};

