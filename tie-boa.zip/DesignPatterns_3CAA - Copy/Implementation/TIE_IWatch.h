#pragma once
#ifdef IMPLEMENTATION_EXPORTS 
#define IMPLEMENTATION_API __declspec(dllexport)
#else
#define IMPLEMENTATION_API __declspec(dllimport)
#endif

#include "CMobile.h"
#include "IWatch.h"

class IMPLEMENTATION_API TIE_IWatch : public IWatch
{
private:
	CMobile* _pcMobile;
public:
	TIE_IWatch();
	TIE_IWatch(CMobile* pcMobile);
	~TIE_IWatch();

	void time();

	void addRef();
	void release();

	void queryInterface(const int TYPE, void** ppv);
	
	IMobile* get_pcMobile();
	void set_pcMobile(CMobile* pcMobile);
};

