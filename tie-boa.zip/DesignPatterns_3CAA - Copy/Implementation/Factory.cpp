#include "pch.h"
#include "Factory.h"
#include "CMobile.h"
#include "TIE_ICalculator.h"
#include "TIE_IWatch.h"

void Factory::getObject(const int TYPE, void** ppv)
{
	CMobile* pcMobile = new CMobile();
	pcMobile->addRef();
	switch (TYPE) {
	case 1: {
		*ppv = (IMobile*)pcMobile;
		break;
	}
	case 2: {
		TIE_ICalculator* tie_iCalculator = new TIE_ICalculator(pcMobile);
		tie_iCalculator->addRef();
		pcMobile->setPICalculator(tie_iCalculator);
		*ppv = tie_iCalculator;
		break;
	}
	case 3: {
		TIE_IWatch* tie_iWatch = new TIE_IWatch(pcMobile);
		tie_iWatch->addRef();
		pcMobile->setPIWatch(tie_iWatch);
		*ppv = tie_iWatch;
		break;
	}

	}
}
