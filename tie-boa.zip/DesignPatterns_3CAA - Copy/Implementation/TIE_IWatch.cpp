#include "pch.h"
#include "TIE_IWatch.h"
#include <iostream>


TIE_IWatch::TIE_IWatch() {
	this->_pcMobile = NULL;
}

TIE_IWatch::TIE_IWatch(CMobile* pcMobile){
	this->_pcMobile = pcMobile;
}

TIE_IWatch::~TIE_IWatch() {
	this->_pcMobile->setPIWatch(NULL);
	std::cout << "TIE_IWatch destructor" << std::endl;
}

void TIE_IWatch::time()
{
	this->_pcMobile->time();
}

void TIE_IWatch::addRef() {
	this->_pcMobile->addRef();
}

void TIE_IWatch::release() {
	this->_pcMobile->release();

}

void TIE_IWatch::queryInterface(const int TYPE, void** ppv) {
	this->_pcMobile->queryInterface(TYPE, ppv);
}

IMobile* TIE_IWatch::get_pcMobile() {
	return this->_pcMobile;
}

void TIE_IWatch::set_pcMobile(CMobile *pcMobile) {
	this->_pcMobile = pcMobile;
}