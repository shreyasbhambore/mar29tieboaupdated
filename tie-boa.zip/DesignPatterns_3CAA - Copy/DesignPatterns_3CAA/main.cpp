// DesignPatterns_3CAA.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "IMobile.h"
#include "ICalculator.h"
#include "IWatch.h"
#include "Factory.h"


const int TYPE_IMOBILE = 1;
const int TYPE_ICALCULATOR = 2;
const int TYPE_IWATCH = 3;


int main()
{
	Factory factory;
	IMobile* piMobile = nullptr;
	// 
	factory.getObject(TYPE_IMOBILE, (void**)&piMobile); // CMobile got created
	piMobile->makeCall(); // ref cnt 1

	ICalculator* piCalculator = nullptr;
	piMobile->queryInterface(TYPE_ICALCULATOR, (void**)&piCalculator); // TIE_ICalculator object crated ref 1
	piMobile->release(); //  ref cnt 0 CMobile
	piCalculator->add();

	//piMobile->queryInterface(TYPE_ICALCULATOR, (void**)&piCalculator);
	//piCalculator->add();


	IWatch* piWatch = nullptr;
	piCalculator->queryInterface(TYPE_IWATCH, (void**)&piWatch); // TIE Watch crated refcnt 1
	piCalculator->release(); // TIE Calcualtor ref cnt 0

	piWatch->time();
	piWatch->release(); // TIE WATCH ref cntn 0 
	//piMobile->release();
}
