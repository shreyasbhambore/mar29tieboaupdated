#pragma once
#ifdef INTERFACES_EXPORTS 
#define INTERFACES_API __declspec(dllexport)
#else
#define INTERFACES_API __declspec(dllimport)
#endif

class INTERFACES_API IUnknown
{
public:
	virtual ~IUnknown();

	virtual void addRef() = 0;
	virtual void release() = 0;

	virtual void queryInterface(const int TYPE, void** ppv) = 0;
};

