#include "pch.h"
#include "IWatch.h"

IWatch::~IWatch() {
}