#pragma once
#ifdef INTERFACES_EXPORTS 
#define INTERFACES_API __declspec(dllexport)
#else
#define INTERFACES_API __declspec(dllimport)
#endif

#include "IUnknown.h"

class INTERFACES_API IWatch : public IUnknown
{
public:
	virtual ~IWatch();
	virtual void time() = 0;
};

