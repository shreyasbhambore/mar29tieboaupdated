#include "pch.h"
#include "ICalculator.h"

ICalculator::~ICalculator() {
}