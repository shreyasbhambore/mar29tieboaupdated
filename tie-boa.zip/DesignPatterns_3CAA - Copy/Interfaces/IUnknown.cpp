#include "pch.h"
#include "IUnknown.h"
#include<iostream>

IUnknown::~IUnknown() {
}
