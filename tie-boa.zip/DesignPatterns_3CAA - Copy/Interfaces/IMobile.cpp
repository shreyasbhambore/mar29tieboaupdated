#include "pch.h"
#include "IMobile.h"

IMobile::~IMobile() {
}