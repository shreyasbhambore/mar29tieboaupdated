#ifdef INTERFACES_EXPORTS 
#define INTERFACES_API __declspec(dllexport)
#else
#define INTERFACES_API __declspec(dllimport)
#endif

#include "IUnknown.h"

class INTERFACES_API IMobile: public IUnknown
{
public:
	virtual ~IMobile();
	virtual void makeCall() = 0;
	virtual void recieveCall() = 0;
};

